package com.example.kevin.front_end;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class eventsList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_list);
    }
}
